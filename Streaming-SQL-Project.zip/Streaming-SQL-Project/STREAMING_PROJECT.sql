USE STREAMING_PROJECT
---------------------SUBSCRIPTION ANALYSIS-----------------------------------------------
--1.TOTAL SUBSCRIPTIONS
SELECT COUNT(subscription_key) AS TOTAL_SUBSCRIPTIONS
FROM subscription_data

--2.Total Revenue from Subscriptions
SELECT plan_type, SUM(amount_paid) AS TOTAL_REVENUE
FROM subscription_data
WHERE plan_type IS NOT NULL
GROUP BY plan_type

--3.Average Revenue per Subscription:
SELECT plan_type,AVG(amount_paid) AS AVG_REVENUE
FROM subscription_data
WHERE plan_type IS NOT NULL
GROUP BY plan_type

--4. Subscriptions percentage by plan type
SELECT plan_type,COUNT(subscription_key)*1.0/(SELECT COUNT(subscription_key)*100 FROM subscription_data) AS [% COUNT]
FROM subscription_data
WHERE plan_type IS NOT NULL
GROUP BY plan_type

--5. Subscriptions percentage by plan duration
SELECT subscription_length AS DURATION,
COUNT(subscription_key)*1.0/(SELECT COUNT(subscription_key)*100 FROM subscription_data) AS [% PLAN]
FROM subscription_data
GROUP BY subscription_length
ORDER BY DURATION

--6. Calculate the total revenue generated per month.
SELECT MONTH(subscription_start_date) AS MONTHS,
SUM(amount_paid) AS REVENUE
FROM subscription_data
GROUP BY MONTH(subscription_start_date)
ORDER BY REVENUE DESC

--7.Monthly New Subscriptions:
SELECT MONTHS,
CASE WHEN
MOM_CHANGE <0
THEN 0
ELSE MOM_CHANGE
END AS CHURNERS
FROM(
		SELECT MONTH(subscription_start_date) AS MONTHS,
		COUNT(subscription_key)-LAG(COUNT(subscription_key),1) OVER (ORDER BY MONTH(subscription_start_date) ) AS MOM_CHANGE
		FROM subscription_data
		GROUP BY MONTH(subscription_start_date)
) AS x
ORDER BY CHURNERS DESC

------------CASE WHEN----------------------------
-- Divide the catalogue data into 2 groups, one where country is India & second will be 
--of US & rest others.
SELECT country,
CASE WHEN
country='INDIA' THEN 'IND' 
WHEN country ='UNITED STATES' THEN 'US'
ELSE 'OTHERS' END AS LABELS
FROM catalogue_data

--8. Understanding when users are purchasing
SELECT MONTHS,
CASE WHEN
MOM_CHANGE <0
THEN 0
ELSE MOM_CHANGE
END AS CHURNERS
FROM(
		SELECT MONTH(subscription_start_date) AS MONTHS,
		COUNT(subscription_key)-LAG(COUNT(subscription_key),1) OVER (ORDER BY MONTH(subscription_start_date) ) AS MOM_CHANGE
		FROM subscription_data
		GROUP BY MONTH(subscription_start_date)
) AS x
ORDER BY CHURNERS DESC


------------------------------CONTENT ANALYSIS----------------------------------------------
--1.Total content
SELECT COUNT(title) AS CONTENT_COUNT
FROM catalogue_data

--2. Total content split by paid & free
SELECT accesslevel,COUNT(title) AS CONTENTS
FROM catalogue_data
GROUP BY accesslevel

--3. Total content split by status
SELECT status,COUNT(title) AS CONTENTS
FROM catalogue_data
GROUP BY status

--4. Month of month content added to the paltform
SELECT MONTHS,CONTENTS,CONTENTS-PREV_CONTENTS AS MOM_CHANGE FROM(
				SELECT DATEPART(MONTH, date_added) AS MONTHS, COUNT(title) AS CONTENTS,
				LAG(COUNT(title),1) OVER(ORDER BY DATEPART(MONTH, date_added)) AS PREV_CONTENTS
				FROM catalogue_data
				GROUP BY DATEPART(MONTH, date_added)
) AS X

--5. Compare MoM count of Indian content added to the platform vs other content added
SELECT * 
FROM(
		SELECT MONTH(date_added) AS MONTHS,COUNT(title) AS CONTENT_COUNT,'INDIA' AS COUNTRY_NAME
		FROM catalogue_data
		WHERE country ='INDIA'
		GROUP BY MONTH(date_added)
		
		UNION ALL 
		SELECT MONTH(date_added) AS MONTHS,COUNT(title) AS CONTENT_COUNT,'OTHERS' AS COUNTRY_NAME
		FROM catalogue_data
		WHERE country <>'INDIA'
		GROUP BY MONTH(date_added)

) AS X
ORDER BY MONTHS

--6. Average duration of content
SELECT CONCAT(AVG(CAST(REPLACE(duration,'MIN','') AS int)),' ','MIN') AS AVG_DURATION
FROM catalogue_data

--7. Which content is pulling in the most number of users?
SELECT TOP 10 title,COUNT(feedback_id) AS REVIEW_COUNT
FROM rating_data AS R
JOIN consumption_data AS C
ON R.usersessionid=C.usersessionid
JOIN catalogue_data AS X
ON X.content_id=C.content_id
WHERE R.rating='AWESOME'
GROUP BY title
ORDER BY REVIEW_COUNT DESC

--8. Different genres of content with the content count
SELECT TOP 10  listed_in,COUNT(title) AS CONTENT_COUNT
FROM catalogue_data
GROUP BY listed_in
ORDER BY CONTENT_COUNT DESC

----------------------------RATING ANALYSIS-------------------------------------
--1. Different rating categories given by the users
SELECT DISTINCT rating
FROM rating_data

--2. Total Content whose rating is not given by the users
SELECT COUNT(feedback_id) AS RATING_COUNT
FROM rating_data
WHERE rating='NOT_RATED'

--3. Contents with the highest rating
SELECT TOP 5 title,COUNT(feedback_id) AS CONTENT_COUNT
FROM rating_data AS X
JOIN consumption_data AS Y
ON X.usersessionid=Y.usersessionid
JOIN catalogue_data AS Z
ON Z.content_id=Y.content_id
WHERE X.rating='AWESOME'
GROUP BY title
ORDER BY CONTENT_COUNT DESC

--4. Which content will be removed in the coming time?
SELECT TOP 10 title--,COUNT(title) AS CONTENT_CNT
FROM catalogue_data
WHERE status='RELEGATED'
GROUP BY title
ORDER BY COUNT(title) DESC

--5. Content from horror categoy
SELECT title--,COUNT(title) AS CAT_CNT
FROM catalogue_data
WHERE listed_in LIKE '%HORROR%'

--6.Top rated content from India
SELECT title,listed_in FROM catalogue_data
WHERE TITLE IN  (
		SELECT TOP 20 title--,listed_in--,COUNT(title) 
		FROM catalogue_data
		WHERE country='INDIA'
		GROUP BY title--,listed_in
		
) 
GROUP BY listed_in,title
ORDER BY COUNT(TITLE)


---------------------------DATA CONTEXT----------------------------------------------
--1. Which is the most watched movie? 
SELECT TOP 1 title,SUM(user_duration) AS MOST_WATCHED
FROM consumption_data AS X
JOIN catalogue_data AS Y
ON X.content_id=Y.content_id
GROUP BY title
ORDER BY MOST_WATCHED DESC

--2. Which movies has not been watched at all?
;CREATE VIEW LEAST_WATCH_TIME
AS(
		SELECT TOP 10 title,SUM(user_duration) AS MOST_WATCHED
		FROM consumption_data AS X
		JOIN catalogue_data AS Y
		ON X.content_id=Y.content_id
		GROUP BY title
		ORDER BY MOST_WATCHED ASC
)
SELECT * FROM LEAST_WATCH_TIME

-- JOIN THE TWO TABLES WITHOUT USING JOINS!
SELECT * FROM catalogue_data AS X,consumption_data AS Y
WHERE X.content_id=Y.content_id

--3. Calculate the % of total revenue generated by the different plan types
SELECT plan_type,
ROUND(SUM(amount_paid)/(SELECT SUM(amount_paid) FROM subscription_data)*100,2) AS [%TOTAL_REVENUE]
FROM subscription_data
WHERE plan_type IS NOT NULL
GROUP BY plan_type

--4. Which movies are helping us aquire most number of users?
SELECT TOP 10 title--,SUM(user_duration)
FROM rating_data AS X
JOIN consumption_data AS Y
ON X.usersessionid=Y.usersessionid
JOIN catalogue_data AS Z
ON Z.content_id=Y.content_id
WHERE X.rating='AWESOME'
GROUP BY title
ORDER BY SUM(user_duration) DESC

--5. All content which has been live for last 6 months
SELECT title
FROM catalogue_data
WHERE status='LIVE'
			AND
		date_added >=(SELECT DATEADD(MONTH,-6,MAX(DATE_ADDED)) FROM catalogue_data)
ORDER BY date_added ASC










































